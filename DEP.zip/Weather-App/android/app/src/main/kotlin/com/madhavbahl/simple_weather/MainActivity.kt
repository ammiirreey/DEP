package com.madhavbahl.simple_weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
